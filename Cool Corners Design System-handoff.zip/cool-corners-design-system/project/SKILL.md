---
name: CoolCorners design system
description: Design system for the CoolCorners community travel-discovery web app. Use whenever the user asks to design or mock up screens, flows, marketing pages, or components for CoolCorners — places, trips, co-travel, events, or user profiles.
---

# CoolCorners design system — agent skill

CoolCorners is a community travel-discovery web app. People browse curated **Places**, plan **Trips**, organize **Co-travel** group plans, and surface local **Events**. Everyone can browse; Keycloak-authenticated users contribute.

It is a **single product** (web), so this skill ships **one UI kit**: `ui_kits/web/`.

## When to use this skill
- Designing any CoolCorners screen, flow, or component
- Producing mocks for new features (Places / Trips / CoTravel / Events / Users)
- Writing in-product copy or empty/loading/error states for CoolCorners
- Anything where the user references "the travel app" / "coolcorners" / "FiserVojta/coolcornersreact"

## Read these first
1. `README.md` — voice, content rules, full visual foundations, iconography rules. **Read in full** before designing anything.
2. `colors_and_type.css` — every token (colors, type, radii, shadows, motion). Link this stylesheet from any new HTML file.
3. `ui_kits/web/README.md` — what each component file exposes.
4. `ui_kits/web/index.html` — load it to see the system in motion before composing new screens.

## Building a new screen
1. Link `colors_and_type.css` and use `var(--…)` tokens, never hardcoded hex.
2. Compose with the kit components — `Header`, `PageHeader`, `SurfaceCard`, `Button`, `Tag`, `RatingStars`, `ContentCard`, `PlaceCard`, etc. Don't reinvent.
3. Layout: `<PageContainer>` (max-w 72rem, py 40px) with sections separated by 32–40px.
4. Card lists: 1 / 2 / 3 column responsive grid, `gap: 24px`.
5. Eyebrow → H1 → muted description → optional action row is the universal page header.

## Hard rules (don't break)
- **No emoji. No exclamation marks.** Anywhere. Including microcopy and CTAs.
- **No icon library.** Unicode `▼` for carets and `—` for empty values is the whole vocabulary. If a feature truly needs glyphs, use Lucide via CDN and flag the deviation.
- **Sentence case** for every title, button, label. Eyebrows are uppercase + 0.2em tracking — that's the only exception.
- **Slate-900 ink, white surfaces, brand-700 accents.** Brand blue is an accent, never a page or card background.
- **No drawn illustrations.** Imagery means real travel photography, `object-cover`, no filters / duotone / grain.
- **One typeface: Inter.** Display and body both resolve to Inter.
- **Cards lift on hover** (`translateY(-4px)` + shadow upgrade) and **inner image scales 1.05 over 500ms**. That's the showpiece motion. No other entrance animations, springs, or bounces.
- **Black is reserved.** Strongest color is slate-900 `#0f172a`, which doubles as primary button bg. Nothing is `#000`.

## Voice cheatsheet
- Page eyebrows: `PLACES`, `TRIPS`, `COTRAVEL`, `EVENTS`, `USERS`.
- Page H1s: "Discover curated corners", "Plan your next wander", "Discover what's happening", "Join community-led trips".
- Counts: "Found 12 trips.", "Fetched from 24 entries.", "Total: 36 events".
- Login-gated CTAs read **"Login to create"** when signed out, action verb when signed in (`Create place`, `Create trip`).
- Empty: "No comments yet.", "No images for this place yet.", "No image".
- Loading: "Loading places…" with a pulsing brand-500 dot.
- Errors: "Unable to load places right now." (rose-50 surface, rose-700 ink).

## Numbers & units
- Duration: `45 min` / `2h` / `2h 30m` / `3 days`.
- Capacity: `12/20 joined`.
- Date: `Mar 14, 2026` or `Mar 14, 2026, 7:30 PM`.
- Rating: `4.5 / 5`, with the 5-star SVG row.

## When you're stuck
If you need a component the kit doesn't have, copy the closest existing one and follow its visual rules: white surface, `border-radius: 16` (cards) or `24` (containers), `shadow-card`, slate-200 borders if any, primary action = slate-900 pill button. Confirm with the user before introducing a new colour or radius.
