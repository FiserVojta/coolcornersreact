// Primitives.jsx — Button, Pill, Eyebrow, PageHeader, SurfaceCard, FormField, TagList, RatingStars, Chip
function Button({ variant = 'primary', size = 'md', children, onClick, disabled, style }) {
  const variants = {
    primary: { background: 'var(--brand-700)', color: '#fff', border: 0 },
    accent: { background: 'var(--accent-700)', color: '#fff', border: 0 },
    secondary: { background: '#fff', color: 'var(--brand-700)', border: '1px solid var(--brand-200)' },
    danger: { background: 'var(--brand-50)', color: 'var(--rose-700)', border: '1px solid var(--brand-200)' },
  };
  const sizes = { sm: { padding: '4px 12px', fontSize: 12 }, md: { padding: '8px 16px', fontSize: 14 } };
  return (
    <button onClick={onClick} disabled={disabled} style={{
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      borderRadius: 9999, fontWeight: 600, transition: 'all 150ms cubic-bezier(.4,0,.2,1)',
      cursor: disabled ? 'not-allowed' : 'pointer', boxShadow: 'var(--shadow-sm)',
      opacity: disabled ? 0.5 : 1,
      ...variants[variant], ...sizes[size], ...style,
    }}>{children}</button>
  );
}

function Eyebrow({ children, muted }) {
  return <p style={{ margin: 0, fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.2em', color: muted ? 'var(--ink-subtle)' : 'var(--brand-700)' }}>{children}</p>;
}

function PageHeader({ eyebrow, title, description, actions }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 16, flexWrap: 'wrap' }}>
        <div>
          <Eyebrow>{eyebrow}</Eyebrow>
          <h1 style={{ margin: '4px 0 0', fontSize: 30, fontWeight: 700, color: 'var(--ink-strong)', letterSpacing: '-0.02em', lineHeight: 1.15 }}>{title}</h1>
          {description ? <p style={{ margin: '8px 0 0', color: 'var(--ink-muted)' }}>{description}</p> : null}
        </div>
        {actions ? <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>{actions}</div> : null}
      </div>
    </div>
  );
}

function SurfaceCard({ children, padding = 'md', style }) {
  const pad = padding === 'lg' ? 24 : 20;
  return <section style={{ background: '#fff', borderRadius: 16, boxShadow: 'var(--shadow-card)', padding: pad, ...style }}>{children}</section>;
}

function FormField({ label, error, children }) {
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 4, fontSize: 14, color: 'var(--ink-default)' }}>
      <span style={{ fontWeight: 600, color: 'var(--ink-strong)' }}>{label}</span>
      {children}
      {error ? <p style={{ margin: 0, fontSize: 12, fontWeight: 600, color: 'var(--rose-600)' }}>{error}</p> : null}
    </label>
  );
}

function TextInput({ value, onChange, type = 'text', placeholder, style }) {
  const [focus, setFocus] = useState(false);
  return (
    <input type={type} value={value || ''} onChange={onChange} placeholder={placeholder}
      onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
      style={{
        width: '100%', boxSizing: 'border-box', borderRadius: 12,
        border: `1px solid ${focus ? 'var(--brand-400)' : 'var(--brand-100)'}`,
        background: '#fff', padding: '8px 12px', fontSize: 14, color: 'var(--ink-strong)',
        boxShadow: 'var(--shadow-sm)', outline: 'none', fontFamily: 'inherit', ...style,
      }} />
  );
}

function TextArea({ value, onChange, placeholder, rows = 3 }) {
  return (
    <textarea value={value || ''} onChange={onChange} placeholder={placeholder} rows={rows}
      style={{
        width: '100%', boxSizing: 'border-box', borderRadius: 12, border: '1px solid var(--brand-100)',
        background: '#fff', padding: '8px 12px', fontSize: 14, color: 'var(--ink-strong)',
        boxShadow: 'var(--shadow-sm)', outline: 'none', fontFamily: 'inherit', resize: 'vertical',
      }} />
  );
}

function Tag({ children, variant = 'outline' }) {
  const styles = {
    outline: { background: '#fff', border: '1px solid var(--brand-100)', color: 'var(--ink-default)' },
    soft: { background: 'var(--brand-50)', color: 'var(--ink-default)', border: 0 },
  };
  return <span style={{ display: 'inline-flex', alignItems: 'center', whiteSpace: 'nowrap', borderRadius: 9999, padding: '4px 10px', fontSize: 12, fontWeight: 600, ...styles[variant] }}>{children}</span>;
}

function TagList({ tags }) {
  if (!tags?.length) return null;
  return <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>{tags.map((t, i) => <Tag key={i}>{t}</Tag>)}</div>;
}

function RatingStars({ rating }) {
  const r = Math.max(0, Math.min(5, rating || 0));
  const full = Math.floor(r);
  const half = r - full >= 0.5;
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 2 }}>
      {[0, 1, 2, 3, 4].map(i => {
        const isFull = i < full;
        const isHalf = i === full && half;
        return (
          <svg key={i} viewBox="0 0 20 20" width={14} height={14} aria-hidden="true">
            {isHalf && (
              <defs>
                <linearGradient id={`star-${i}`} x1="0" x2="1" y1="0" y2="0">
                  <stop offset="50%" stopColor="#f59e0b" />
                  <stop offset="50%" stopColor="#cbd5f5" />
                </linearGradient>
              </defs>
            )}
            <path d="M10 1.5l2.6 5.3 5.9.9-4.2 4.1 1 5.9L10 14.7 4.7 17.7l1-5.9L1.5 7.7l5.9-.9L10 1.5z"
              fill={isHalf ? `url(#star-${i})` : isFull ? '#f59e0b' : '#cbd5f5'} />
          </svg>
        );
      })}
    </span>
  );
}

function FloatChip({ children, position = 'tl', style }) {
  const pos = position === 'tl' ? { left: 12, top: 12 } : { right: 12, top: 12 };
  return <div style={{ position: 'absolute', ...pos, background: 'rgba(255,255,255,.92)', padding: '4px 10px', borderRadius: 9999, fontSize: 12, fontWeight: 600, color: 'var(--ink-default)', boxShadow: 'var(--shadow-sm)', whiteSpace: 'nowrap', display: 'inline-flex', alignItems: 'center', gap: 6, ...style }}>{children}</div>;
}

function PageContainer({ children, style }) {
  return <main style={{ maxWidth: '72rem', margin: '0 auto', padding: '40px 16px', ...style }}>{children}</main>;
}

function LoadingState({ label = 'Loading...' }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'center', padding: '64px 0' }}>
      <div style={{ display: 'inline-flex', alignItems: 'center', gap: 12, background: '#fff', padding: '12px 16px', borderRadius: 9999, fontSize: 14, fontWeight: 600, color: 'var(--ink-default)', boxShadow: 'var(--shadow-sm)' }}>
        <span style={{ width: 10, height: 10, borderRadius: 9999, background: 'var(--brand-500)', animation: 'cc-pulse 1.6s infinite' }} />
        {label}
      </div>
    </div>
  );
}

Object.assign(window, { Button, Eyebrow, PageHeader, SurfaceCard, FormField, TextInput, TextArea, Tag, TagList, RatingStars, FloatChip, PageContainer, LoadingState });
