// Cards.jsx — Place / Trip / Event / CoTravel / User cards
const formatDuration = (m) => {
  if (!m) return '—';
  if (m < 60) return `${m} min`;
  if (m < 1440) {
    const h = Math.floor(m / 60); const min = m % 60;
    return min ? `${h}h ${min}m` : `${h}h`;
  }
  const d = Math.floor(m / 1440);
  return `${d} day${d > 1 ? 's' : ''}`;
};
const formatDate = (s) => new Date(s).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
const formatDateTime = (s) => new Date(s).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' });

function ContentCard({ image, alt, chipTL, chipTR, title, pill, description, tags, onClick }) {
  const [hover, setHover] = React.useState(false);
  return (
    <a onClick={onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        display: 'flex', flexDirection: 'column', overflow: 'hidden',
        borderRadius: 16, background: '#fff',
        boxShadow: hover ? '0 20px 50px rgba(8, 49, 27,.14)' : 'var(--shadow-card)',
        transform: hover ? 'translateY(-4px)' : 'translateY(0)',
        transition: 'all 250ms cubic-bezier(.4,0,.2,1)',
        cursor: 'pointer',
      }}>
      <div style={{ position: 'relative', height: 200, background: 'var(--brand-50)', overflow: 'hidden' }}>
        {image ? (
          <img src={image} alt={alt} style={{
            width: '100%', height: '100%', objectFit: 'cover',
            transform: hover ? 'scale(1.05)' : 'scale(1)',
            transition: 'transform 500ms cubic-bezier(.4,0,.2,1)',
          }} />
        ) : (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', color: 'var(--slate-400)', fontSize: 14, fontWeight: 600 }}>No image</div>
        )}
        {chipTL && <FloatChip position="tl">{chipTL}</FloatChip>}
        {chipTR && <FloatChip position="tr">{chipTR}</FloatChip>}
      </div>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 12, padding: '12px 16px 16px' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8 }}>
          <h3 style={{ margin: 0, fontSize: 18, fontWeight: 600, color: 'var(--ink-strong)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{title}</h3>
          {pill && <Tag variant="soft">{pill}</Tag>}
        </div>
        <p style={{ margin: 0, fontSize: 14, color: 'var(--ink-muted)', lineHeight: 1.5,
          display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{description}</p>
        <TagList tags={tags} />
      </div>
    </a>
  );
}

function PlaceCard({ place, onClick }) {
  return (
    <ContentCard
      image={place.image} alt={place.name}
      chipTR={<><RatingStars rating={place.rating} /><span style={{ color: 'var(--ink-default)' }}>{place.rating?.toFixed(1)} / 5</span></>}
      title={place.name} pill={place.city} description={place.description} tags={place.tags}
      onClick={() => onClick?.(place)} />
  );
}

function TripCard({ trip, onClick }) {
  return (
    <ContentCard
      image={trip.image} alt={trip.name}
      chipTR={<><RatingStars rating={trip.rating} /><span style={{ color: 'var(--ink-default)' }}>{trip.rating?.toFixed(1)} / 5</span></>}
      title={trip.name} pill={formatDuration(trip.duration)} description={trip.description} tags={trip.tags}
      onClick={() => onClick?.(trip)} />
  );
}

function EventCard({ event, onClick }) {
  return (
    <ContentCard
      image={event.image} alt={event.name}
      chipTL={formatDateTime(event.startTime)}
      title={event.name} pill={formatDuration(event.duration)} description={event.description} tags={event.tags}
      onClick={() => onClick?.(event)} />
  );
}

function CotravelCard({ plan, onClick }) {
  return (
    <ContentCard
      image={plan.image} alt={plan.name}
      chipTL={`${plan.filled}/${plan.capacity} joined`}
      title={plan.name} pill={formatDate(plan.startTime)} description={plan.description} tags={plan.tags}
      onClick={() => onClick?.(plan)} />
  );
}

function UserCard({ user, onClick }) {
  const [hover, setHover] = React.useState(false);
  const initials = (user.name || user.email || '').split(' ').map(p => p[0]).slice(0, 2).join('').toUpperCase();
  return (
    <a onClick={() => onClick?.(user)}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        display: 'flex', flexDirection: 'column', gap: 12, padding: 16,
        borderRadius: 16, background: '#fff', border: '1px solid var(--brand-50)',
        boxShadow: hover ? '0 20px 50px rgba(8, 49, 27,.14)' : 'var(--shadow-card)',
        transform: hover ? 'translateY(-4px)' : 'translateY(0)',
        transition: 'all 250ms cubic-bezier(.4,0,.2,1)', cursor: 'pointer',
      }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ width: 48, height: 48, borderRadius: 9999, background: 'var(--brand-100)', color: 'var(--brand-700)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 700 }}>{initials}</div>
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink-strong)' }}>{user.name}</span>
          <span style={{ fontSize: 12, color: 'var(--ink-subtle)' }}>{user.email}</span>
        </div>
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--ink-muted)' }}>
        <span>Followers: {user.followers}</span>
        <span>Following: {user.following}</span>
        <span>Joined: {user.joined}</span>
      </div>
    </a>
  );
}

Object.assign(window, { ContentCard, PlaceCard, TripCard, EventCard, CotravelCard, UserCard });
