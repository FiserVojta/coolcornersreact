# CoolCorners — Web UI kit

A click-thru recreation of the **CoolCorners** React web app (single product surface).

## Files
- `index.html` — interactive prototype with header, navigation, and 6 screens.
- `Header.jsx` — sticky top nav, login/logout state.
- `Primitives.jsx` — `Button`, `Eyebrow`, `PageHeader`, `SurfaceCard`, `FormField`, `TextInput`, `TextArea`, `Tag`, `TagList`, `RatingStars`, `FloatChip`, `PageContainer`, `LoadingState`.
- `Cards.jsx` — `ContentCard` (the shared image-led card pattern), `PlaceCard`, `TripCard`, `EventCard`, `CotravelCard`, `UserCard`.
- `Screens.jsx` — `HomeScreen`, `PlacesScreen`, `TripsScreen` (with multi-select filter), `EventsScreen`, `CotravelScreen`, `PlaceDetailScreen` (overview / details / comments / rate).
- `fixtures.js` — sample places, trips, events, co-travel plans, categories, tags.

## What works in the prototype
- Click any nav item to navigate.
- Toggle login (top-right) — gated CTAs (`Create place`, `Post comment`) flip between primary and "Login to create".
- Click any place card → detail screen with comments (post one!) and rating.
- Open the multi-select filter on Trips — categories and tags toggle independently.

## What's intentionally cosmetic only
- No real auth, no real fetch, no map (the codebase uses Keycloak + react-leaflet).
- Edit / Create forms are not wired (the codebase has heavy `react-hook-form` work in `pages/*/*Form.tsx`).
- Pagination buttons are not exposed in screens (component lives in `Primitives.jsx` if needed).
