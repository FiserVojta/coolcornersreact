// fixtures.js — sample data
window.CC_FIXTURES = {
  places: [
    { id: 1, name: 'Café Lumi', city: 'Prague', category: 'Café', rating: 4.7, description: 'Sun-drenched café tucked into a quiet courtyard, known for cardamom buns and slow pour-overs.', address: 'Vinohradská 12, Prague', openingHours: '8:00 – 18:00', phone: '+420 222 333 444', website: 'cafelumi.cz', tags: ['Café', 'Cosy'], comments: [{ name: 'Hanna', value: 'Got a window seat at 9am — perfect.' }], image: 'https://images.unsplash.com/photo-1453614512568-c4024d13c247?auto=format&fit=crop&w=1200&q=80', image2: 'https://images.unsplash.com/photo-1521017432531-fbd92d768814?auto=format&fit=crop&w=1200&q=80' },
    { id: 2, name: 'Pavilion Park', city: 'Brno', category: 'Park', rating: 4.3, description: 'Functionalist pavilion overlooking a lake, popular for slow afternoons and reading.', tags: ['Park', 'Outdoor'], image: 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=1200&q=80' },
    { id: 3, name: 'Old Town Bridge', city: 'Český Krumlov', category: 'Landmark', rating: 4.9, description: 'Cobblestone footbridge over the Vltava with a view of the castle towers at sunset.', tags: ['Landmark', 'Scenic'], image: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=1200&q=80' },
    { id: 4, name: 'Farmer’s Market', city: 'Olomouc', category: 'Market', rating: 4.5, description: 'Saturday morning market with regional cheeses, plums, and fresh kolaches.', tags: ['Market', 'Food'], image: 'https://images.unsplash.com/photo-1488459716781-31db52582fe9?auto=format&fit=crop&w=1200&q=80' },
    { id: 5, name: 'Quiet Library', city: 'Prague', category: 'Library', rating: 4.6, description: 'A century-old reading room with green-shaded lamps and creaky parquet floors.', tags: ['Library', 'Quiet'], image: 'https://images.unsplash.com/photo-1507842217343-583bb7270b66?auto=format&fit=crop&w=1200&q=80' },
    { id: 6, name: 'Riverside Walk', city: 'Plzeň', category: 'Trail', rating: 4.2, description: 'Two-kilometre paved walk under poplars, great for a slow evening loop.', tags: ['Trail', 'Outdoor'], image: 'https://images.unsplash.com/photo-1465056836041-7f43ac27dcb5?auto=format&fit=crop&w=1200&q=80' },
  ],
  trips: [
    { id: 1, name: 'Northern Lights Escape', rating: 4.8, duration: 3 * 1440, description: 'Glacier hike along the southern coast, ending at a hot spring under the aurora.', tags: ['Iceland', 'Coastal'], image: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80' },
    { id: 2, name: 'Alpine Trails', rating: 4.6, duration: 2 * 1440, description: 'Two-day ridge hike across Swiss meadows. Refuge stay at the saddle.', tags: ['Hiking', 'Mountains'], image: 'https://images.unsplash.com/photo-1505761671935-60b3a7427bad?auto=format&fit=crop&w=1200&q=80' },
    { id: 3, name: 'Greek Island Hopping', rating: 4.7, duration: 5 * 1440, description: 'Five days, four ferries, three islands. Slow mornings and warm sea afternoons.', tags: ['Island', 'Coastal'], image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80' },
    { id: 4, name: 'Savanna Safari', rating: 4.9, duration: 6 * 1440, description: 'Guided wildlife circuit through Tanzania\'s northern parks.', tags: ['Safari', 'Wildlife'], image: 'https://images.unsplash.com/photo-1508672019048-805c876b67e2?auto=format&fit=crop&w=1200&q=80' },
    { id: 5, name: 'Southeast Asia Backpack', rating: 4.4, duration: 14 * 1440, description: 'Slow loop through northern Thailand and Laos.', tags: ['Backpack', 'Asia'], image: 'https://images.unsplash.com/photo-1505765050516-f72dcac9c60e?auto=format&fit=crop&w=1200&q=80' },
    { id: 6, name: 'Vineyard Weekend', rating: 4.3, duration: 2 * 1440, description: 'Riding between Moravian wineries, dinner under string lights.', tags: ['Food', 'Slow'], image: 'https://images.unsplash.com/photo-1506377247377-2a5b3b417ebb?auto=format&fit=crop&w=1200&q=80' },
  ],
  events: [
    { id: 1, name: 'Old Town Jazz Night', startTime: '2026-05-04T20:00', duration: 180, description: 'Open-air trio set in the courtyard of the old library.', tags: ['Music'], image: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?auto=format&fit=crop&w=1200&q=80' },
    { id: 2, name: 'Coffee & Make Workshop', startTime: '2026-05-09T10:00', duration: 240, description: 'Hands-on pour-over workshop with three regional roasters.', tags: ['Workshop'], image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=1200&q=80' },
    { id: 3, name: 'Riverside Festival', startTime: '2026-06-15T16:00', duration: 720, description: 'Two stages, six bands, regional food trucks along the embankment.', tags: ['Festival'], image: 'https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?auto=format&fit=crop&w=1200&q=80' },
    { id: 4, name: 'Founders Meetup', startTime: '2026-05-22T18:30', duration: 120, description: 'Casual round-table for early-stage founders and operators.', tags: ['Network'], image: 'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?auto=format&fit=crop&w=1200&q=80' },
  ],
  cotravel: [
    { id: 1, name: 'Northern Lights Escape', startTime: '2026-11-12', filled: 4, capacity: 6, description: 'Looking for two more for the Iceland aurora trip in November.', tags: ['Iceland'], image: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80' },
    { id: 2, name: 'Alpine Trails', startTime: '2026-07-04', filled: 3, capacity: 5, description: 'Two-day Swiss ridge hike — slow pace, refuge stay.', tags: ['Hiking'], image: 'https://images.unsplash.com/photo-1505761671935-60b3a7427bad?auto=format&fit=crop&w=1200&q=80' },
    { id: 3, name: 'Savanna Safari', startTime: '2026-09-20', filled: 5, capacity: 8, description: 'Tanzania circuit. Two seats remain after final deposits.', tags: ['Safari'], image: 'https://images.unsplash.com/photo-1508672019048-805c876b67e2?auto=format&fit=crop&w=1200&q=80' },
  ],
  categories: [
    { id: 1, label: 'Hiking' }, { id: 2, label: 'Coastal' }, { id: 3, label: 'City' }, { id: 4, label: 'Food' }, { id: 5, label: 'Wildlife' }, { id: 6, label: 'Music' },
  ],
  tags: [
    { id: 1, label: 'Slow' }, { id: 2, label: 'Family' }, { id: 3, label: 'Solo' }, { id: 4, label: 'Budget' }, { id: 5, label: 'Outdoor' }, { id: 6, label: 'Indoor' },
  ],
};
