// Screens.jsx — Home, PlacesList, TripsList, EventsList, CotravelList, PlaceDetail
function Hero({ onBrowse, onTrips }) {
  return (
    <section style={{
      borderRadius: 24,
      background: 'linear-gradient(135deg, var(--brand-900) 0%, var(--brand-700) 45%, var(--accent-700) 100%)',
      padding: '48px 32px', boxShadow: '0 30px 80px rgba(8, 49, 27, .35)', color: '#fff',
      position: 'relative', overflow: 'hidden',
    }}>
      <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 85% 15%, rgba(255,255,255,.12), transparent 40%)', pointerEvents: 'none' }} />
      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: 24, position: 'relative' }}>
        <div style={{ maxWidth: 640, display: 'flex', flexDirection: 'column', gap: 16 }}>
          <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--brand-200)', textTransform: 'uppercase', letterSpacing: '0.2em' }}>CoolCorners</span>
          <h1 style={{ margin: 0, fontSize: 36, fontWeight: 700, color: '#fff', letterSpacing: '-0.02em', lineHeight: 1.15 }}>
            Explore curated places and trips with the community
          </h1>
          <p style={{ margin: 0, fontSize: 18, color: 'rgba(255,255,255,.78)', lineHeight: 1.6 }}>
            Discover hand-picked corners, plan trips, and join community-led wanders. Browse openly — sign in to contribute.
          </p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, marginTop: 4 }}>
            <button onClick={onBrowse} style={{ borderRadius: 9999, background: '#fff', color: 'var(--brand-800)', border: 0, padding: '10px 20px', fontSize: 14, fontWeight: 600, cursor: 'pointer', boxShadow: 'var(--shadow-sm)' }}>Browse places</button>
            <button onClick={onTrips} style={{ borderRadius: 9999, background: 'transparent', color: '#fff', border: '1px solid rgba(255,255,255,.4)', padding: '10px 20px', fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>View trips</button>
          </div>
        </div>
        <div style={{ width: 256, height: 160, borderRadius: 16, background: 'rgba(255,255,255,.08)', backdropFilter: 'blur(8px)', border: '1px solid rgba(255,255,255,.15)' }} />
      </div>
    </section>
  );
}

function Filters({ children }) {
  return (
    <section style={{
      borderRadius: 24, border: '1px solid var(--brand-100)', background: '#fff',
      padding: 20, boxShadow: 'var(--shadow-sm)', display: 'flex', flexDirection: 'column', gap: 16,
    }}>{children}</section>
  );
}

function MultiSelect({ label, options, selected, onToggle, placeholder = 'Select' }) {
  const [open, setOpen] = useState(false);
  const labels = options.filter(o => selected.includes(o.id)).map(o => o.label).join(', ');
  return (
    <div style={{ position: 'relative', flex: 1, minWidth: 220 }}>
      <p style={{ margin: 0, fontSize: 12, fontWeight: 700, color: 'var(--ink-subtle)', textTransform: 'uppercase', letterSpacing: '0.2em' }}>{label}</p>
      <button onClick={() => setOpen(o => !o)} style={{
        marginTop: 8, width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        borderRadius: 16, border: '1px solid var(--brand-100)', background: '#fff',
        padding: '8px 12px', fontSize: 14, fontWeight: 600, color: 'var(--ink-default)',
        boxShadow: 'var(--shadow-sm)', cursor: 'pointer',
      }}>
        <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', paddingRight: 12 }}>{labels || placeholder}</span>
        <span style={{ fontSize: 11, color: 'var(--ink-subtle)', transform: open ? 'rotate(180deg)' : 'rotate(0)', transition: 'transform 150ms' }}>▼</span>
      </button>
      {open && (
        <div style={{ position: 'absolute', left: 0, right: 0, zIndex: 20, marginTop: 8, maxHeight: 240, overflowY: 'auto', borderRadius: 16, border: '1px solid var(--brand-100)', background: '#fff', padding: 8, boxShadow: 'var(--shadow-lg)' }}>
          {options.map(opt => {
            const active = selected.includes(opt.id);
            return (
              <button key={opt.id} onClick={() => onToggle(opt.id)} style={{
                display: 'flex', width: '100%', borderRadius: 12, padding: '8px 12px', fontSize: 14,
                background: active ? 'var(--brand-700)' : 'transparent',
                color: active ? '#fff' : 'var(--ink-default)', border: 0, textAlign: 'left', cursor: 'pointer',
              }}>{opt.label}</button>
            );
          })}
        </div>
      )}
    </div>
  );
}

function HomeScreen({ onNavigate }) {
  return (
    <PageContainer style={{ display: 'flex', flexDirection: 'column', gap: 40 }}>
      <Hero onBrowse={() => onNavigate('/places')} onTrips={() => onNavigate('/trips')} />
    </PageContainer>
  );
}

function PlacesScreen({ places, authenticated, onPlace, onLogin, onNavigate }) {
  return (
    <PageContainer>
      <PageHeader eyebrow="Places" title="Discover curated corners"
        description={`Fetched from ${places.length} entries.`}
        actions={authenticated
          ? <Button onClick={() => onNavigate('/places/create')}>Create place</Button>
          : <Button variant="secondary" onClick={onLogin}>Login to create</Button>} />
      <div style={{ marginTop: 32, display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 24 }}>
        {places.map(p => <PlaceCard key={p.id} place={p} onClick={() => onPlace(p)} />)}
      </div>
    </PageContainer>
  );
}

function TripsScreen({ trips, categories, tags, authenticated, onLogin }) {
  const [selCats, setSelCats] = useState([]);
  const [selTags, setSelTags] = useState([]);
  const toggle = (list, set) => (id) => set(list.includes(id) ? list.filter(x => x !== id) : [...list, id]);
  return (
    <PageContainer>
      <PageHeader eyebrow="Trips" title="Plan your next wander" description={`Found ${trips.length} trips.`}
        actions={authenticated ? <Button>Create trip</Button> : <Button variant="secondary" onClick={onLogin}>Login to create</Button>} />
      <div style={{ marginTop: 32 }}>
        <Filters>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 16, alignItems: 'flex-end' }}>
            <MultiSelect label="Categories" options={categories} selected={selCats} onToggle={toggle(selCats, setSelCats)} placeholder="Select categories" />
            <MultiSelect label="Tags" options={tags} selected={selTags} onToggle={toggle(selTags, setSelTags)} placeholder="Select tags" />
            <Button variant="secondary" onClick={() => { setSelCats([]); setSelTags([]); }}>Clear filters</Button>
          </div>
        </Filters>
      </div>
      <div style={{ marginTop: 32, display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 24 }}>
        {trips.map(t => <TripCard key={t.id} trip={t} />)}
      </div>
    </PageContainer>
  );
}

function EventsScreen({ events, authenticated, onLogin }) {
  return (
    <PageContainer>
      <PageHeader eyebrow="Events" title="Discover what’s happening" description={`Found ${events.length} events.`}
        actions={authenticated ? <Button>Create event</Button> : <Button variant="secondary" onClick={onLogin}>Login to create</Button>} />
      <div style={{ marginTop: 32, display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 24 }}>
        {events.map(e => <EventCard key={e.id} event={e} />)}
      </div>
    </PageContainer>
  );
}

function CotravelScreen({ plans, authenticated, onLogin }) {
  return (
    <PageContainer>
      <PageHeader eyebrow="CoTravel" title="Join community-led trips" description={`Found ${plans.length} co-travel plans.`}
        actions={authenticated ? <Button>Create plan</Button> : <Button variant="secondary" onClick={onLogin}>Login to create</Button>} />
      <div style={{ marginTop: 32, display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 24 }}>
        {plans.map(p => <CotravelCard key={p.id} plan={p} />)}
      </div>
    </PageContainer>
  );
}

function PlaceDetailScreen({ place, authenticated, onBack, onLogin }) {
  const [comment, setComment] = useState('');
  const [comments, setComments] = useState(place.comments || []);
  const [rated, setRated] = useState(null);
  const submit = (e) => { e.preventDefault(); if (!comment.trim()) return; setComments([...comments, { name: 'You', value: comment }]); setComment(''); };
  return (
    <PageContainer>
      <Button variant="secondary" size="sm" onClick={onBack} style={{ marginBottom: 16 }}>← Back to places</Button>
      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: 16 }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <Eyebrow>{place.category || 'Place'}</Eyebrow>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <h1 style={{ margin: 0, fontSize: 30, fontWeight: 700, color: 'var(--ink-strong)', letterSpacing: '-0.02em' }}>{place.name}</h1>
            <span style={{ background: 'var(--brand-600)', color: '#fff', padding: '4px 12px', borderRadius: 9999, fontSize: 12, fontWeight: 600, boxShadow: 'var(--shadow-sm)' }}>{place.rating?.toFixed(1)}</span>
          </div>
          <p style={{ margin: 0, color: 'var(--ink-muted)' }}>{place.address || place.city}</p>
        </div>
      </div>
      <div style={{ marginTop: 24, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <img src={place.image} alt="" style={{ height: 288, width: '100%', borderRadius: 16, objectFit: 'cover', boxShadow: 'var(--shadow-card)' }} />
        <img src={place.image2 || place.image} alt="" style={{ height: 288, width: '100%', borderRadius: 16, objectFit: 'cover', boxShadow: 'var(--shadow-card)' }} />
      </div>
      <div style={{ marginTop: 40, display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 40 }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
          <SurfaceCard padding="lg">
            <h2 style={{ margin: 0, fontSize: 20, fontWeight: 600, color: 'var(--ink-strong)' }}>Overview</h2>
            <p style={{ marginTop: 8, color: 'var(--ink-default)', lineHeight: 1.7 }}>{place.description}</p>
            <div style={{ marginTop: 16 }}><TagList tags={place.tags} /></div>
          </SurfaceCard>
          <SurfaceCard padding="lg">
            <h3 style={{ margin: 0, fontSize: 18, fontWeight: 600, color: 'var(--ink-strong)' }}>Details</h3>
            <div style={{ marginTop: 12, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              {[['City', place.city], ['Opening hours', place.openingHours], ['Phone', place.phone], ['Website', place.website]].map(([l, v]) => (
                <div key={l} style={{ borderRadius: 12, border: '1px solid var(--brand-50)', background: 'var(--brand-50)', padding: '8px 12px' }}>
                  <p style={{ margin: 0, fontSize: 11, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--ink-subtle)' }}>{l}</p>
                  <p style={{ margin: '4px 0 0', color: 'var(--ink-strong)', fontSize: 14 }}>{v || '—'}</p>
                </div>
              ))}
            </div>
          </SurfaceCard>
        </div>
        <aside style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
          <SurfaceCard>
            <h3 style={{ margin: 0, fontSize: 18, fontWeight: 600, color: 'var(--ink-strong)' }}>Comments</h3>
            {comments.length ? (
              <ul style={{ margin: '12px 0 0', padding: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 12, fontSize: 14, color: 'var(--ink-default)' }}>
                {comments.map((c, i) => (
                  <li key={i} style={{ borderRadius: 12, border: '1px solid var(--brand-50)', background: 'var(--brand-50)', padding: '8px 12px' }}>
                    <p style={{ margin: 0, fontWeight: 600, color: 'var(--ink-strong)' }}>{c.name || 'Visitor'}</p>
                    <p style={{ margin: '2px 0 0' }}>{c.value}</p>
                  </li>
                ))}
              </ul>
            ) : <p style={{ margin: '12px 0 0', fontSize: 14, color: 'var(--ink-muted)' }}>No comments yet.</p>}
            {authenticated ? (
              <form onSubmit={submit} style={{ marginTop: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>
                <TextArea value={comment} onChange={e => setComment(e.target.value)} placeholder="Add a comment" rows={2} />
                <Button size="sm" onClick={submit}>Post comment</Button>
              </form>
            ) : (
              <p style={{ marginTop: 12, fontSize: 14, color: 'var(--ink-muted)' }}>Please login to comment. <Button variant="secondary" size="sm" onClick={onLogin} style={{ marginLeft: 8 }}>Login</Button></p>
            )}
          </SurfaceCard>
          <SurfaceCard>
            <h3 style={{ margin: 0, fontSize: 18, fontWeight: 600, color: 'var(--ink-strong)' }}>Rate this place</h3>
            <div style={{ marginTop: 8, display: 'flex', gap: 8 }}>
              {[1, 2, 3, 4, 5].map(s => (
                <button key={s} onClick={() => setRated(s)} style={{
                  width: 36, height: 36, borderRadius: 9999, fontSize: 14, fontWeight: 600,
                  background: rated && rated >= s ? 'var(--brand-600)' : '#fff',
                  color: rated && rated >= s ? '#fff' : 'var(--ink-strong)',
                  border: '1px solid var(--brand-100)', cursor: 'pointer',
                }}>{s}</button>
              ))}
            </div>
          </SurfaceCard>
        </aside>
      </div>
    </PageContainer>
  );
}

Object.assign(window, { HomeScreen, PlacesScreen, TripsScreen, EventsScreen, CotravelScreen, PlaceDetailScreen });
