// Header.jsx — sticky top nav from src/components/Header.tsx
const { useState } = React;

function Header({ activeRoute = '/', authenticated = false, username = 'vojta', onNavigate, onLogin, onLogout }) {
  const items = [
    { to: '/', label: 'Home' },
    { to: '/places', label: 'Places' },
    { to: '/trips', label: 'Trips' },
    { to: '/cotravel', label: 'CoTravel' },
    { to: '/events', label: 'Events' },
    { to: '/users', label: 'Users' },
  ];
  return (
    <header style={{
      position: 'sticky', top: 0, zIndex: 30,
      borderBottom: '1px solid rgba(168, 220, 184,.45)',
      background: 'rgba(255,255,255,.7)', backdropFilter: 'blur(10px)', WebkitBackdropFilter: 'blur(10px)'
    }}>
      <div style={{ maxWidth: '72rem', margin: '0 auto', padding: '14px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16 }}>
        <a onClick={() => onNavigate?.('/')} style={{ fontSize: 18, fontWeight: 600, color: 'var(--ink-strong)', letterSpacing: '-0.02em', cursor: 'pointer' }}>CoolCorners</a>
        <nav style={{ display: 'flex', gap: 24, alignItems: 'center' }}>
          {items.map((it) => {
            const active = activeRoute === it.to;
            return (
              <a key={it.to}
                onClick={() => onNavigate?.(it.to)}
                style={{ fontSize: 14, fontWeight: 500, cursor: 'pointer',
                  color: active ? 'var(--brand-700)' : 'var(--ink-muted)' }}>
                {it.label}
              </a>
            );
          })}
        </nav>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          {authenticated ? (
            <>
              <span style={{ fontSize: 14, color: 'var(--ink-muted)' }}>Hi, {username}</span>
              <button onClick={onLogout} style={{
                borderRadius: 9999, background: 'var(--brand-700)', color: '#fff',
                padding: '6px 14px', fontSize: 14, fontWeight: 600, border: 0,
                boxShadow: 'var(--shadow-sm)', cursor: 'pointer'
              }}>Logout</button>
            </>
          ) : (
            <button onClick={onLogin} style={{
              borderRadius: 9999, background: '#fff', color: 'var(--brand-700)',
              border: '1px solid var(--brand-200)', padding: '6px 14px', fontSize: 14, fontWeight: 600,
              boxShadow: 'var(--shadow-sm)', cursor: 'pointer'
            }}>Login</button>
          )}
        </div>
      </div>
    </header>
  );
}

window.Header = Header;
