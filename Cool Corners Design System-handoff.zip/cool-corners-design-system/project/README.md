# CoolCorners Design System

A design system distilled from the **CoolCorners** React web app — a community travel-discovery product where people browse curated **Places**, plan **Trips**, organize **Co-travel** group plans, and surface local **Events**. Authenticated users (via Keycloak) can create and edit content; everyone can browse.

## Sources

This system was extracted from a single repo:

- **Codebase**: `https://github.com/FiserVojta/coolcornersreact` — React 19 + Vite + TypeScript + Tailwind CSS, with React Query, React Router 7, react-hook-form, react-leaflet, Keycloak.
- Backend (referenced only): `https://github.com/FiserVojta/coolCornersSpringBoot`.

No Figma file, brand book, or marketing site was provided — visual rules below were inferred directly from `tailwind.config.js`, `src/index.css`, and the component source. Reader doesn't need access; the relevant code is captured here and in `colors_and_type.css`.

Surfaces in the codebase:
- `Home` — landing hero
- `Places` (list + detail + form), `Trips` (list + detail + form)
- `CoTravel` (list + detail + form) — group travel plans
- `Events` (list + detail + form)
- `Users` (list + detail) — community profiles
- Header navigation w/ login/logout, comment threads, ratings, file upload, embedded Mapy.cz Leaflet map.

It's a **single product** (a web app), so this design system has **one UI kit**: `ui_kits/web/`.

---

## Index

| File / Folder              | Purpose |
|----------------------------|---------|
| `README.md`                | This file — brand, content & visual fundamentals, iconography. |
| `colors_and_type.css`      | All color, type, spacing, radius, shadow, motion tokens as CSS vars + semantic classes (`.cc-h1`, `.cc-eyebrow`, etc). |
| `assets/`                  | `coolcorners-mark.svg` (the brand mark used as favicon). |
| `preview/`                 | Cards rendered into the Design System tab. |
| `ui_kits/web/`             | High-fidelity recreation of the React web app — Header, cards, forms, page layouts, click-thru screens. Open `ui_kits/web/index.html` to see the system in motion. |
| `SKILL.md`                 | Agent Skill manifest — read this first when picking up the system in a new chat. |

### Quick start for a new screen
1. Link `colors_and_type.css` and reference everything via `var(--…)` tokens.
2. Compose with components from `ui_kits/web/` — `Header`, `PageHeader`, `SurfaceCard`, `Button`, `Tag`, `RatingStars`, `ContentCard`, etc.
3. Wrap in `<PageContainer>`; section rhythm is 32–40px.
4. Follow the hard rules in `SKILL.md` (no emoji, no icons, sentence case, slate-900 ink, Inter only, cards lift on hover).

---

## Content fundamentals

**Voice.** Warm, plain, slightly aspirational — written like an editor introducing curated content, not like marketing. No exclamation marks anywhere in the codebase. No emoji.

**Person.** Speaks **to the user** in second person ("Plan your next wander", "Rate this place") and **about the platform** in third person ("Found 24 trips."). Never uses "we".

**Casing.** **Sentence case** for everything — H1s, buttons, nav, even page eyebrows are uppercase but written sentence-style underneath.
- ✅ "Discover curated corners", "Browse places", "Create trip"
- ❌ "Discover Curated Corners", "Browse Places"
- Eyebrows are uppercase + wide-tracked (`tracking-[0.2em]`): `PLACES`, `COTRAVEL`, `TRIPS`.

**Sample copy lifted from the app** (use as voice reference):
- Hero eyebrow + H1 + lede:
  > **COOLCORNERS** — *Explore curated places and trips with Keycloak-ready React. This React port mirrors your Angular routes starting with Places. Auth is wired for Keycloak, ready for incremental rollout.*
- Page headers:
  > "Discover curated corners" — "Fetched from 24 entries."
  > "Plan your next wander" — "Found 12 trips."
  > "Discover what's happening" — "Found 36 events."
  > "Join community-led trips" — "Found 8 co-travel plans."
- Buttons: `Browse places`, `View trips`, `Create event`, `Login to create`, `Apply filters`, `Reset`, `Clear filters`, `Page size`, `Previous`, `Next`, `Post comment`, `Rate this place`, `Upload`.
- Empty / loading: `Loading places...`, `Unable to load places right now.`, `No comments yet.`, `No images for this place yet.`, `No image` (card placeholder), `Hi, {username}`.
- Section labels: `Overview`, `Details`, `Comments`, `Rate this place`, `Upload a file`, `Uploaded files`, `Location`.
- Filter labels (uppercase eyebrows in forms): `STARTS FROM`, `STARTS UNTIL`, `CREATED BY`, `CATEGORIES`, `TAGS`, `PAGE SIZE`.

**Numbers & units.** Durations rendered as `45 min` / `2h` / `2h 30m` / `3 days`. Counts as `12/20 joined`. Dates as `Mar 14, 2026, 7:30 PM` (US locale, short month). Ratings as `4.5 / 5`. "Total: 24 events" suffix on pagination.

**Tone do / don't.**
- ✅ Direct, calm, confident: "Loading trips…", "Unable to load events right now.", "Select multiple categories or tags to narrow the list."
- ✅ Light brand voice on the home hero only.
- ❌ No marketing hyperbole, no emoji, no rallying CTAs ("Let's go!", "Get started today!"), no greetings on every page.

**Punctuation.** Periods on full-sentence helper text. No periods on button labels, page titles, eyebrows, or short metadata. Em-dash `—` used as the empty-value glyph in detail tiles (`<Detail label="Phone" value={value ?? '—'} />`).

---

## Visual foundations

The aesthetic is **clean utility-first SaaS** — soft pastel page background, white card surfaces, Slate-900 ink for headings, dark green brand for accents only. It is *not* maximalist; restraint is the brand.and.

### Color
- **Brand green (single hue scale):** `#1f8a52` (500 / default), `#15703f` (600), `#0f5a32` (700 — eyebrows + active nav). Used as **accents**, never as page or card backgrounds. Brand-100 (`#d6efde`) appears as soft avatar / icon-tile backgrounds.
- **Slate neutrals carry the UI.** `#f8fafc` page bg, `#ffffff` cards, `#0f172a` headings, `#475569` body, `#64748b` meta, `#e2e8f0` borders.
- **Emerald + teal** show up sparingly: emerald-100/700 for the "you can edit" badge; teal-700 in the page-bg radial gradient. They're inherited Tailwind defaults, not custom-toned.
- **Amber `#f59e0b`** for star fills, with `#cbd5f5` (slate-300-ish) for empty stars. Half-stars use a 50/50 SVG linearGradient.
- **Rose-50 / rose-200 / rose-700** = the danger surface (delete buttons, error rows). Soft tinted bg, never solid red.
- **Black is reserved.** The strongest color in the UI is `slate-900` `#0f172a`, which doubles as the **primary button background** ("Browse places", "Create trip"). Nothing is true black.

### Type
- **Inter** everywhere — both `display` and `body` Tailwind aliases resolve to Inter. (`Inter var` preferred, fallback `system-ui`.)
- Tracking is **tight on display** (`tracking-tight` on the wordmark and H1), **wide on eyebrows** (`tracking-[0.2em]`).
- Weights: 400 body, 600 semibold for cards/labels/buttons, 700 bold for H1.
- Sizes: H1 `30px` / `36px md+`, card title `18px`, body `14–16px`, meta `12–14px`.

### Spacing & layout
- **Page container:** `max-w-6xl` / `max-w-page` (72rem) centered, `px-4 py-10–12`.
- **Grids:** card lists are `grid gap-6 sm:grid-cols-2 lg:grid-cols-3`.
- **Section rhythm:** PageHeader → `mt-8` filter card → `mt-8` results grid → `mt-10` pagination.
- Tailwind's default 4px-based spacing scale. Most padding is `p-4 / p-5 / p-6`, gaps `gap-3 / gap-4 / gap-6`.

### Backgrounds
- **App page background** is two soft radial gradients on slate-50:
  ```css
  radial-gradient(circle at 20% 20%, rgba(45,117,245,0.08), transparent 25%),
  radial-gradient(circle at 80% 0%,  rgba(15,118,110,0.08), transparent 30%),
  #f8fafc;
  ```
  Ambient green/teal bloom, very low-saturation — you barely see it but it removes flatness.
- **Hero section** uses an inline `bg-gradient-to-br from-brand-50 via-white to-emerald-50` panel.
- **No textures, no patterns, no illustrations, no full-bleed photography in chrome.** The only photography is the **content photography** — Unsplash images on Place / Trip / Event / CoTravel cards, always object-cover-cropped. Warm, natural-light travel photography (mountains, festivals, food, cities). Color-neutral, never B&W or grain.
- Empty image slot: `bg-slate-100` with centered "No image" text in `slate-400`.

### Cards (the dominant visual element)
- White surface, `rounded-2xl` (16px), `shadow-card` = `0 10px 40px rgba(15,23,42,0.08)`.
- No visible border (border absent or `border-slate-100`).
- `overflow-hidden` so the cover image bleeds to the rounded corners.
- Cover image height: 192–208px (`h-48` to `h-52`).
- Body padding: `px-4 pb-4 pt-3`, gap-3 vertical between title-row, description, tags.
- **Hover:** card lifts `-translate-y-1`, shadow upgrades to `shadow-xl`, image inside scales `1.05` over 500ms with `transition duration-500`.
- Pinned chip overlays (date, rating, capacity): `bg-white/90` pill with `shadow-sm`, `text-xs font-semibold`, positioned `top-3 left-3` or `top-3 right-3`.

### Hover & press states
- **Primary button** (`bg-slate-900`): hover → `bg-slate-800`, hero CTA also lifts `-translate-y-0.5`.
- **Secondary button** (`bg-white border-slate-300`): hover → `border-slate-400`.
- **Danger button** (`bg-rose-50 border-rose-200 text-rose-700`): hover → `border-rose-300`.
- **Cards:** lift + shadow upgrade (above).
- **Nav links:** default `text-slate-600` → hover `text-slate-900`; active `text-brand-700`.
- **Disabled:** `disabled:cursor-not-allowed disabled:opacity-50` (or `0.7`).
- **No press / active state** is defined in the codebase — buttons don't shrink. A 150ms `transition` is enough.

### Borders
- Card: usually borderless, sometimes `border-slate-100` or `border-slate-200`.
- Inputs / select dropdowns: `border-slate-200` 1px, focus → `border-brand-400` (no ring).
- Pill chips: `border-slate-200 bg-white` or `bg-slate-100` borderless.
- Filter sections: `rounded-3xl border-slate-200 bg-white p-5 shadow-sm` — the larger 24px radius distinguishes containers from cards.

### Shadows
- `shadow-sm` — chips, sticky header bottom, inline pills.
- `shadow-card` — every card and surface (10px 40px slate-900/8%).
- `shadow-xl` — card hover state.
- `shadow-lg` — popover / dropdown menus.
- `shadow-inner` — empty-image placeholder strip; "you can edit" hero side panel.
- No outer glows, no neon, no colored shadows.

### Corner radii
- Pills (`rounded-full`): every button, every chip / tag / badge, page-counter.
- `rounded-xl` (12): inputs, comment list rows, "detail tile" cells.
- `rounded-2xl` (16): cards, surface cards, secondary panels.
- `rounded-3xl` (24): hero section, filter container.

### Header / navigation
- `sticky top-0`, `bg-white/70 backdrop-blur` (the only place transparency + blur is used).
- Bottom border `border-slate-200/80`.
- Wordmark "CoolCorners" — `text-lg font-semibold tracking-tight text-slate-900`. **Not** the SVG mark — the mark is favicon-only.
- Center nav: `text-sm font-medium`, active state swaps color, no underline / no pill.

### Animation
- Universal `transition` (Tailwind's default = `150ms cubic-bezier(0.4,0,0.2,1)` across colors / borders / shadow / transform).
- Card image hover: `duration-500` zoom — the one slow motion in the system.
- `LoadingState` uses `animate-pulse` on a 10px brand-500 dot.
- Caret rotation on dropdowns: `${open ? 'rotate-180' : ''}` with default transition.
- **No bounces, no spring, no fancy easing, no entrance animations.** Calm.

### Transparency & blur
- Sticky header (`bg-white/70 backdrop-blur`).
- Card overlay chips (`bg-white/90`).
- Side hero panel (`bg-white/70 shadow-inner`).
- That's it — used for layering over scrolling content or imagery only.

### Inputs
- `w-full rounded-xl border-slate-200 bg-white px-3 py-2 text-sm shadow-sm`.
- Focus: `outline-none focus:border-brand-400`. **No box-shadow ring** — the brand-400 border is the entire focus indicator. Subtle, but consistent.
- Field label is its own `<span>` above the input, `font-semibold text-slate-900 text-sm`.
- Error: `<p class="text-xs font-semibold text-rose-600">`.

### Pagination & counters
- Two secondary buttons flanking a black pill: `bg-slate-900 text-white px-4 py-2 rounded-full text-sm font-semibold` reading `Page 1 of 4`. Total label `text-sm text-slate-500` to the side.

### Layout rules
- Sticky header on every page.
- Content `mx-auto max-w-6xl px-4 py-10`.
- 12-column responsive: 1col mobile → 2col `sm` → 3col `lg`.
- `grid-cols-[2fr,1fr]` two-column splits on detail pages (main / aside).
- The hero `<div>` empty-decoration block (`h-40 w-64 rounded-2xl bg-white/70 shadow-inner`) is the only intentional empty slot — a placeholder shape, not an icon.

---

## Iconography

CoolCorners ships with **almost no iconography** — and that restraint is part of the brand.

- **Icon library:** none installed. No Lucide / Heroicons / Feather / Phosphor / Material Icons. No icon font.
- **SVGs in the codebase:** only **two** — the `coolcorners-mark.svg` favicon (an orange-to-teal gradient rounded square holding a stylized "C" + dot, in a cream cutout), and the inline 5-star rating glyph drawn directly inside `PlaceCard` and `TripCard`.
- **Unicode characters as icons:** `▼` for dropdown carets, `—` for empty values. That's the entire icon vocabulary.
- **Emoji:** never — zero occurrences in the codebase.
- **Substitutes for affordance:** the system relies on **layout, color, and labelled buttons** instead of icons. "Login", "Create event", "Apply filters", "Previous", "Next" — buttons are text-only.
- **Avatars:** initials in a colored circle (`bg-brand-100 text-brand-700`), not photos.

### When you need an icon (substitution rule)
If a new feature genuinely needs glyphs (e.g. a media player, a calendar grid), **substitute Lucide via CDN** — outline style, 1.5px stroke, 16/20/24 sizes — which matches the airy, low-weight feel of the existing UI. Flag the substitution to the team; this is a deviation from the current product, not an established choice.

```html
<!-- if needed: Lucide CDN, FLAG when used -->
<script src="https://unpkg.com/lucide@latest"></script>
```

### Imagery
The "iconography" of CoolCorners is really **its photography**. Cards are dominated by warm, natural-light Unsplash travel photos. There are **no stock illustrations, no isometric scenes, no spot illustrations**. Imagery rules:
- Always `object-cover` inside the card frame.
- No filters, no duotone, no grain, no overlays.
- Travel-genre subjects only: landscapes, festivals, urban scenes, food, gatherings.
- Card chips (date, rating, capacity) sit on top in `bg-white/90` for contrast.
